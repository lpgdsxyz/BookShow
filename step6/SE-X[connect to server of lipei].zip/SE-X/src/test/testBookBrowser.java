package test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import junit.framework.TestCase;
import book.*;

public class testBookBrowser extends TestCase {

	private bookbrowser testBookBrowser;

	public void setUp(){
		testBookBrowser=new bookbrowser();
	}
	
	public void tearDown(){
		;
	}

	public void testBookBrowser(){
		String fname=new String(testBookBrowser.f.getTitle());
		String jbt1name=new String(testBookBrowser.jbt1.getText());
		String jbt2name=new String(testBookBrowser.jbt2.getText());
		String jbt3name=new String(testBookBrowser.jbt3.getText());
		
		assertEquals(fname,"ͼ�����");
		assertEquals(jbt1name,"ȷ��");
		assertEquals(jbt2name,"����");
		assertEquals(jbt3name,"��");
		
	}
	
	public void testConnect(){
		try{
			Class.forName("org.gjt.mm.mysql.Driver");
		}
		catch(ClassNotFoundException e){
			System.out.println("������������ʧ�ܣ�");
		}
		
		try{

			Connection con=(Connection) DriverManager.getConnection("jdbc:mysql://172.18.33.178/test","root","123456");
			assertTrue(!con.isClosed());
		}
		catch(Exception e){
			assertTrue(false);
		}
	}
	
	public void testQueryDB(){
		try{
			Class.forName("org.gjt.mm.mysql.Driver");
		}
		catch(ClassNotFoundException e){
			System.out.println("������������ʧ�ܣ�");
		}
		
		try{

			Connection con=(Connection) DriverManager.getConnection("jdbc:mysql://172.18.33.178/test","root","123456");
			Statement sql=con.createStatement();
			String s="select * from mybook ";
			ResultSet rs=sql.executeQuery(s);
			assertNotNull(rs);
		}
		catch(Exception e){
			assertTrue(false);
		}
	}
	
	
}
