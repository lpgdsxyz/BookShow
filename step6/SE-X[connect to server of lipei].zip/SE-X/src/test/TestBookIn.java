package test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import junit.framework.TestCase;

import book.*;

public class TestBookIn extends TestCase {
	
	private BookIn testBookIn;
	
	public void setUp(){
		testBookIn=new BookIn();
	}
	
	public void tearDown(){
		
	}
	public void testBookIn() {
		String f3name=new String(testBookIn.f3.getTitle());
		String jbt1name=new String(testBookIn.jbt1.getText());
		String jbt2name=new String(testBookIn.jbt2.getText());
		
		assertEquals(f3name,"ͼ�����");
		assertEquals(jbt1name,"ȷ��");
		assertEquals(jbt2name,"ȡ��");
	}

	public void testConnect(){
		try{
			Class.forName("org.gjt.mm.mysql.Driver");
		}
		catch(ClassNotFoundException e){
			System.out.println("������������ʧ�ܣ�");
		}
		
		try{

			Connection con=(Connection) DriverManager.getConnection("jdbc:mysql://172.18.33.178/test","root","123456");
			assertTrue(!con.isClosed());
		}
		catch(Exception e){
			assertTrue(false);
		}
	}
	
	public void testInsertRecord() {
		try{
			Class.forName("org.gjt.mm.mysql.Driver");
		}
		catch(ClassNotFoundException e){System.out.println("������������ʧ�ܣ�");}
		try{

			Connection con=(Connection) DriverManager.getConnection("jdbc:mysql://172.18.33.178/test","root","123456");
			Statement sql=con.createStatement();
			
			//����һ�����û�����
			String insertNewBook="insert into mybook(name,number,price,author,press,time,dir) value('NewName','NewNumber','NewPrice','NewAuthor','NewPress','NewTime','NewDir')";
			sql.executeUpdate(insertNewBook);
			
			System.out.println("cha ru");
			
			//Ȼ�����Ƿ�����һ��
			String queryMima="select * from mybook where name='NewName' and number='NewNumber' and price='NewPrice' and author='NewAuthor' and press='NewPress' and time='NewTime' and dir='NewDir'";
			ResultSet rs=sql.executeQuery(queryMima);
			
			assertTrue(rs.next());
			System.out.println("cha xun");
			
			//ɾ��������
			String deleteNewBook="delete from mybook where name='NewName' and number='NewNumber' and price='NewPrice' and author='NewAuthor' and press='NewPress' and time='NewTime' and dir='NewDir'";
			sql.executeUpdate(deleteNewBook);
			
			System.out.println("shan chu");
				
		}catch(SQLException e)
		{
			System.out.println(e.getMessage());
			assertTrue(false);
		}
	}
}
