package test;

import junit.framework.TestCase;

public class TestBook extends TestCase {

	public void testBook() {
		//fail("Not yet implemented");
	}

	public void testBookString() {
		//fail("Not yet implemented");
	}

	public void testActionPerformed() {
		//fail("Not yet implemented");
	}

	public void testMain() {
		//fail("Not yet implemented");
	}

}
