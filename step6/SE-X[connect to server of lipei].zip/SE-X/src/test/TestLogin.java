package test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import junit.framework.TestCase;
import book.*;

public class TestLogin extends TestCase {
	private Login testLogin;
	
	public void setUp(){
		testLogin=new Login();
	}
	
	public void tearDown(){
		
	}
	
	public void testGetUname(){
		testLogin.getUname();
		assertEquals(testLogin.t1.getText(),testLogin.uname);
	}
	
	public void testGetPswd(){
		testLogin.getPswd();
		assertEquals(testLogin.t2.getText(),testLogin.Mima);
	}
	
	public void testLogin() {
		
		String fname=new String(testLogin.f.getTitle());
		String j1name=new String(testLogin.j1.getText());
		String j2name=new String(testLogin.j2.getText());
		String jlabel1name=new String(testLogin.jlabel1.getText());
		String jlabel2name=new String(testLogin.jlabel2.getText());
		
		assertEquals(fname,"С��ͼ�����ϵͳ");
		assertEquals(j1name,"ȷ��");
		assertEquals(j2name,"ȡ��");
		assertEquals(jlabel1name,"�����û���");
		assertEquals(jlabel2name,"�û�����");
	}

	public void testConfirm() {
		try{
			Class.forName("org.gjt.mm.mysql.Driver");
		}
		catch(ClassNotFoundException e){System.out.println("������������ʧ�ܣ�");}
		try{

			Connection con=(Connection) DriverManager.getConnection("jdbc:mysql://172.18.33.178/test","root","123456");
			Statement sql=con.createStatement();
			
			//���Ȳ���һ���û�����
			String insertNewUser="insert into myuser(name,password) value('NewUser','NewPswd')";
			sql.executeUpdate(insertNewUser);
			
			System.out.println("cha ru");
			
			//Ȼ�����ܷ��¼
			String queryMima="select * from myuser where name='NewUser' and password='NewPswd'";
			ResultSet rs=sql.executeQuery(queryMima);
			
			System.out.println("cha xun");
			
			assertTrue(rs.next());
			
			//ɾ��������
			String deleteNewUser="delete from myuser where name='NewUser' and password='NewPswd'";
			sql.executeUpdate(deleteNewUser);
			
			System.out.println("shan chu");
			
			
		}catch(SQLException e)
		{
			System.out.println(e.getMessage());
			assertTrue(false);
		}
	}

	public void testConnect(){
		try{
			Class.forName("org.gjt.mm.mysql.Driver");
		}
		catch(ClassNotFoundException e){
			System.out.println("������������ʧ�ܣ�");
		}
		
		try{

			Connection con=(Connection) DriverManager.getConnection("jdbc:mysql://172.18.33.178/test","root","123456");
			assertTrue(!con.isClosed());
		}
		catch(Exception e){
			assertTrue(false);
		}
	}
	
	public void testIsPswdVisible(){
		boolean visible=testLogin.t2.isVisible();
		System.out.println(visible);
		assertTrue(visible);
	}
}

