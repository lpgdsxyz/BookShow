package book;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.util.*;
import javax.swing.*;

import java.awt.*;
import java.io.IOException;

import javax.swing.*;
import javax.swing.border.TitledBorder;


public class Book extends JFrame implements ActionListener
{
	JButton QueryScore=new JButton("ͼ���ѯ");
	JButton QueryXuefen=new JButton("ͼ�����");
	JButton jiangfa=new JButton("ͼ��ɾ��");
	JButton xuanke=new JButton("ͼ��Ԥ��");
	JButton gaiMima=new JButton("�޸�����");
	JMenuBar mb=new JMenuBar();//�˵�
	JPanel jp=new JPanel();//���������ģ��
	Container cp=getContentPane();
	String username;
	//JButton open = new JButton("��doc");
	//JTextField dir = new JTextField();
	Book()
	{
		
	}
	Book(String username)
	{
		this.username=username;
		mb.add(QueryScore);
		mb.add(QueryXuefen);
		mb.add(jiangfa);
		mb.add(jiangfa);
		mb.add(xuanke);
		mb.add(gaiMima);
		cp.add(mb,"North");
		
		//���ñ߿�
		//jp.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.blue,2),null,TitledBorder.CENTER,TitledBorder.TOP));
		jp.setBorder(BorderFactory.createMatteBorder(300,300,300,300,new ImageIcon("D:/DDP/DDPjiemian.JPG")));
		jp.setLayout(new GridLayout(6,1));
		ImageIcon   image=new ImageIcon("D:/DDP/sb_pc_snowed_1.jpg");
		setIconImage(image.getImage());
		JScrollPane scrollpane=new JScrollPane(jp);
		//jp.add(open);
		//jp.add(dir);
		cp.add(scrollpane);
		setTitle("��ӭ��½");
		
		Toolkit kit=Toolkit.getDefaultToolkit();
		Dimension screen=kit.getScreenSize();
		int x=screen.width;
    	int y=screen.height;
    	setSize(600,600);
    	int xcenter=(x-600)/2;

        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //ע��������
        QueryScore.addActionListener(this);
        QueryXuefen.addActionListener(this);
        jiangfa.addActionListener(this);
        xuanke.addActionListener(this);
        gaiMima.addActionListener(this);
        //open.addActionListener(this);
        
	}
	public void actionPerformed(ActionEvent e)
	{
		String cmd=e.getActionCommand();
		if(cmd.equals("ͼ���ѯ"))
		{
			new QueryBook();
		}
		if(cmd.equals("ͼ�����"))
		{
			new BookIn();
		}
	    if (cmd.equals("ͼ��ɾ��"))
	    {
	    	new Removebook();
	    }
	    if(cmd.equals("ͼ��Ԥ��"))
	    {
	    	new bookbrowser().showRecord();
	    }
		if(cmd.equals("�޸�����"))
		{
			new UpdateM(username);
		}
		if(cmd.equals("��doc"))
		{
			//try {
			//	Runtime.getRuntime().exec("C:/Program Files/Microsoft Office/Office12/WINWORD.exe "+dir.getText());
			//} catch (IOException e1) {
				// TODO �Զ����� catch ��
			//	e1.printStackTrace();
			//} 
		}
	}
	
	
	public static void main(String[] args) {
		// TODO �Զ����ɷ������

		new Login();
		//new Book("");
	}
}