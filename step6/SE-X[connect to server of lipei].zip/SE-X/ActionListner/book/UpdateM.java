package book;
import java.awt.event.*;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Toolkit;
import javax.swing.*;

import java.awt.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.border.TitledBorder;

public class UpdateM extends JFrame implements ActionListener
{
	JFrame f;
	Container cp;
	JPanel jp1,jp2,jp3,jp4,jpanelWest;
	JButton jbt1,jbt2;
	JLabel label;
	JTextField name;
	JPasswordField tf1,tf2,tf3;
	JLabel label1,label2,label3,label4;
	String sno;
	UpdateM(){};
	UpdateM(String username)
	{
		sno=username;
		f=new JFrame();
		cp=f.getContentPane();//��ʼ��
		jp1=new JPanel();
		jp2=new JPanel();
		jp3=new JPanel();
		jp4=new JPanel();
		jpanelWest=new JPanel();
		
		jbt1=new JButton("ȷ��");
		jbt2=new JButton("ȡ��");
		
		label=new JLabel("<html><font color=#cc00ff size='4'>�޸�����</front>",SwingConstants.CENTER);
    	label.setForeground(Color.blue);
    	label.setFont(new Font("BOLD",Font.BOLD,15));
		name=new JTextField(20);
		
		tf1=new JPasswordField(20);
		tf2=new JPasswordField(20);
		tf3=new JPasswordField(20);
		
		jp1.add(jbt1);
		jp1.add(jbt2);
		
		//jp1.add(new JLabel("����"+"xx"+"��ӭ��½ѧ����Ϣϵͳ"));
		
		JPanel jpanel=new JPanel();
		jpanel.add(label);
		
		JPanel pp4=new JPanel();
	    JPanel jane4=new JPanel();
	    
	    cp.add(jpanel,"North");
	    JPanel pp2=new JPanel(new GridLayout(6,1));
	    JPanel pp3=new JPanel();
	    pp4.setLayout(new GridLayout(6,1));
	    pp4.add(new JLabel("�û���",SwingConstants.RIGHT));
	    pp2.add(name);
	    pp4.add(new JLabel("ԭ����:",SwingConstants.RIGHT));
	    
	    pp2.add(tf1);
	    pp4.add(new JLabel("������:",SwingConstants.RIGHT));
	    pp2.add(tf2);
	    pp4.add(new JLabel("ȷ������:",SwingConstants.RIGHT));
	    pp2.add(tf3);
	    pp2.add(new JLabel());
	    JPanel jpbutton=new JPanel();
	    jpbutton.add(jbt1);
	    jpbutton.add(jbt2);
	    pp2.add(jpbutton);
	    
	    cp.add(jp1,"South");
	    cp.add(pp2,"Center");
	    cp.add(pp4,"West");
	    
		Toolkit kit=Toolkit.getDefaultToolkit();
    	Dimension screen=kit.getScreenSize();
    	int x=screen.width;
    	int y=screen.height;
    	f.setSize(400,330);
    	int xcenter=(x-350)/2;
    	int ycenter=(y-350)/2;
    	f.setLocation(xcenter,ycenter);
    	f.setVisible(true);
    	jbt1.addActionListener(this);
    	jbt2.addActionListener(this);
	}
	public void updateM()
	{
		try{
			Class.forName("org.gjt.mm.mysql.Driver");
    	}
    	catch(ClassNotFoundException e)
    	{
    		System.out.println("������������ʧ�ܣ�");
    	}
    	try{
    	//	String url="jdbc:odbc:driver={Microsoft Access Driver (*.mdb)};DBQ=Book.mdb";
			Connection con=(Connection) DriverManager.getConnection("jdbc:mysql://172.18.33.178/test","root","123456");

   
    		Statement sql=con.createStatement();
    		String uname=name.getText().trim();
    		String s="select * from myuser where name='"+uname+"'";
    		
    		ResultSet rs=sql.executeQuery(s);
    		
    		if(rs.next())
    		{
    			String newMima=tf2.getText().trim();
    			String ss=" update myuser set password='"+newMima+"' where name='"+uname+"'"; 
    		    sql=con.createStatement();
    		    int updateMima=sql.executeUpdate(ss);
    		    if(updateMima==1)
    		    {
    		    	JOptionPane.showMessageDialog(f,"�����޸ĳɹ���");
    		    }
    		    con.close();
    		    f.repaint();
    		}
    		else
    		{
    			JOptionPane.showMessageDialog(null,"�û������ڣ�","����",JOptionPane.YES_NO_OPTION);
    		}
    		name.setText("");
    		tf1.setText("");
    		tf1.setText("");
    		tf1.setText("");
    	}catch(SQLException g)
    	{
    		System.out.println("E Code"+g.getErrorCode());
    		System.out.println("E M"+g.getMessage());
    	}
		
	}
	public void actionPerformed(ActionEvent e)
	{
		String cmd=e.getActionCommand();
		if(cmd.equals("ȷ��"))
		{
			if(name.getText().equals("")||tf1.getText().equals("")||tf2.getText().equals("")
					||tf3.getText().equals(""))
			{
				JOptionPane.showMessageDialog(null, "����д�û�������Ϣ","��ʾ",JOptionPane.YES_NO_OPTION);
				return;
			}
			if(tf2.getText().trim().equals(tf3.getText().trim()))
				updateM();
		}
		else if(cmd.equals("ȡ��"))
		{
			f.hide();
		}
	}
}