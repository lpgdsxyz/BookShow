package book;
import java.awt.event.*;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.util.*;
import javax.swing.*;

import java.awt.*;
import javax.swing.*;

public class Removebook implements ActionListener
{
	public JFrame f;
	Container cp;
	JPanel jpS,jpanelWest;
	public JButton jbt1;//��ť����ѯ��ȡ������
	public JButton jbt2;
	public JButton jbt3;
	public JButton jbt4;
	JLabel label,L; 
	JTextField tf;//�����ı���
	 Object columnName[]={"ͼ����","ͼ���","����","����","������","���ʱ��","��ַ"};
	 public Object ar[][]=new Object[80][7];
	 String sno;
	 String count="xx";
	 JTable table;
	    
	    public Removebook()
	    {
	    	f=new JFrame();
	    	cp=f.getContentPane(); //��ʼ����壬��ť����ǩ���ı���
	    	jpS=new JPanel();
	    	jpanelWest=new JPanel();
	    	jbt1=new JButton("��ѯ");
	    	jbt2=new JButton("ȡ��");
	    	jbt3=new JButton("ɾ��");
	    	jbt4=new JButton("��");
	    	
	    	
	    	label=new JLabel("<html><font color=#cc00ff size='4'>������Ҫɾ����ͼ������</front>",SwingConstants.CENTER);
	    	label.setForeground(Color.blue);
	    	L=new JLabel("������ڹ���ͼ��"+count+"��");
	    	
	    	table=new JTable(ar,columnName);//ar��ű������ݡ�columnname��ʾ����
	    	JScrollPane scrollpane=new JScrollPane(table);
	    	
	    	tf=new JTextField(18);
	    	jpS.add(jbt1);
	    	jpS.add(jbt2);
	    	jpS.add(jbt3);
	    	jpS.add(jbt4);
	    	
	    	JPanel jpanel=new JPanel();
	    	jpanel.add(label);
	    	jpanel.add(tf);
	    	
	    	JPanel pp4=new JPanel();
	    	JPanel jpE=new JPanel();
	    	
	    	cp.add(jpanel,"North");
	    	JPanel jp=new JPanel();
	    	JPanel p=new JPanel();//������������
	    	p.setLayout(new BorderLayout());
	    	
	    	p.add(L,"North");
	    	p.add(scrollpane);
	    	
	    	cp.add(pp4,"West");
	    	cp.add(p,"Center");
	    	cp.add(jpS,"South");
	    	cp.add(jpE,"East");
	    	
	    	Toolkit kit=Toolkit.getDefaultToolkit();
	    	Dimension screen=kit.getScreenSize();
	    	int x=screen.width;
	    	int y=screen.height;
	    	f.setSize(400,330);
	    	int xcenter=(x-350)/2;
	    	int ycenter=(y-350)/2;
	    	f.setLocation(xcenter,ycenter);
	    	f.setVisible(true);
	    	jbt1.addActionListener(this);
	    	jbt2.addActionListener(this);
	    	jbt3.addActionListener(this);
	    	jbt4.addActionListener(this);
	    }
	    
	public void showRecord(String ql)
	{
		int i=0;
		while(i>=0)
		{
			ar[i][0]="";
			ar[i][1]="";
			ar[i][2]="";
			ar[i][3]="";
			ar[i][4]="";
			ar[i][5]="";
			ar[i][6]="";
			i--;
		}
		i=0;
		try{
			//Class.forName("sun.jdbc.odbc.jdbcodbcdriver");
			//String url="jdbc:odbc:driver={Microsoft Access Driver (*.mdb)};DBQ=Book.mdb";
			Class.forName("org.gjt.mm.mysql.Driver");//.newInstance(); 
		}
		catch(ClassNotFoundException e)
		{
			System.out.println("������������ʧ�ܣ�");
		}
		try{
			//String url="jdbc:odbc:driver={Microsoft Access Driver (*.mdb)};DBQ=Book.mdb";
			String url="jdbc:mysql://172.18.33.178/test";  

			Connection con=(Connection) DriverManager.getConnection(
					"jdbc:mysql://172.18.33.178/test","root","123456"); 

			Statement sql=con.createStatement();
			String s="select * from mybook where name='"+ql+"'";
			ResultSet rs=sql.executeQuery(s);
			System.out.println("liiiiii");
			while(rs.next())
			{
				String bname=rs.getString(1);
				String bno=rs.getString(2);
				String price=rs.getString(3);
				String writer=rs.getString(4);
				String publish=rs.getString(5);
				String indate=rs.getString(6);
				String dir=rs.getString(7);
				ar[i][0]=bname;
				ar[i][1]=bno;
				ar[i][2]=price;
				ar[i][3]=writer;
				ar[i][4]=publish;
				ar[i][5]=indate;
				ar[i][6]=dir;
				i++;
			}
			count=""+i+"";
			L.setText("��ͼ�鹲��ͼ��"+count+"��");
			f.repaint();
			
			con.close();
			System.out.println(ar[0][1]);
		}catch(SQLException g)
		{
			System.out.println("E Code"+g.getErrorCode());
			System.out.println("E M"+g.getMessage());
		}
	}
	public void deleteRecord(int index)
	{
		try{
			Class.forName("org.gjt.mm.mysql.Driver");
		}
		catch(ClassNotFoundException e){System.out.println("������������ʧ�ܣ�");}
		try{

			Connection con=(Connection) DriverManager.getConnection("jdbc:mysql://172.18.33.178/test","root","123456");
			Statement sql=con.createStatement();
			String ql=(String)(ar[index][1]);
			String s="delete from mybook where number='"+ql+"'";
			 int del=sql.executeUpdate(s);//���ز�ѯ��� 
			if(del==1)
			{
				JOptionPane.showMessageDialog(null,"ɾ���ɹ���","��Ϣ",JOptionPane.YES_NO_OPTION);
			}
                con.close();
                f.repaint();
		}catch(SQLException g)
		{
			System.out.println("E Code"+g.getErrorCode());
    		System.out.println("E M"+g.getMessage());
                
			}
	}
	//@SuppressWarnings("deprecation")
	public void actionPerformed(ActionEvent e)
	{
	String cmd=e.getActionCommand();
	String remember="";
	String ql="";
		if(cmd.equals("��ѯ"))
		{
			ql=tf.getText().trim();
			remember=ql;
			showRecord(ql);
		}
		if(cmd.equals("ɾ��"))
		{
			int index=table.getSelectedRow();
			if(index==-1)
			{
				JOptionPane.showMessageDialog(null,"��ѡ��ɾ���ı����У�","�������",JOptionPane.YES_NO_OPTION);
			}
			else
			{
				deleteRecord(index);
			}
		}
		if(cmd.equals("ȡ��"))
		{
			f.hide();
		}
		if(cmd.equals("��"))
		{
			 int row = table.getSelectedRow();
		        int column = table.getSelectedColumn();

		        DefaultCellEditor obj = (DefaultCellEditor) (table.getColumnModel()
		                .getColumn(column).getCellEditor());
		        
		           

		            System.out.println("row:" + row + " ,column:" + column + " ,value:"
		                    );
		        
			try {
				Runtime.getRuntime().exec("C:/Program Files/Microsoft Office/OFFICE11/WINWORD.exe "+ar[row][6]);
			} catch (IOException e1) {
				// TODO �Զ����� catch ��
				e1.printStackTrace();
			} 
		}
	}			
}

	
