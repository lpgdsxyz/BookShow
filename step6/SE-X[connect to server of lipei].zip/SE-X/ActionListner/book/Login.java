package book;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Toolkit;
import javax.swing.*;

import java.awt.*;

public class Login extends JFrame implements ActionListener
{
	Container cp=null;
	public JFrame f=null;
	public JButton j1,j2;
	public JTextField t1;
	public JPasswordField t2;
	public JLabel jlabel1,jlabel2;
	public Color c;
	public JPanel jp1,jp2;
	
	public String uname;
	public String Mima;
	
	public void getUname(){
		uname=t1.getText().trim();
		//System.out.println(uname);
	}
	
	
	public void getPswd(){
		Mima=t2.getText().trim();
		//System.out.println(Mima);
	}
	
	public Login()
	{
		f=new JFrame("С��ͼ�����ϵͳ");
		j1=new JButton("ȷ��");
		j2=new JButton("ȡ��");
		cp=f.getContentPane();
		jlabel1=new JLabel("�����û���");
		jlabel2=new JLabel("�û�����");
		
		
		jp1=new JPanel();
		jp2=new JPanel();
		t1=new JTextField(18);
		t2=new JPasswordField(18);
		
		jp1.add(jlabel1);
		jp1.add(t1);
		jp1.add(jlabel2);
		jp1.add(t2);
		
		JLabel JL=new JLabel("<html><font color=#cc00ff size='7'><i>��ӭ��¼" +
				"</i></font>",SwingConstants.CENTER);
		cp.add(JL,"North");
		jp2.add(j1);
		jp2.add(j2);
		cp.add(jp1,"Center");
		cp.add("South",jp2);
		jp1.setBackground(new Color(255,153,255));
		
		Toolkit kit=Toolkit.getDefaultToolkit();
		Dimension screen=kit.getScreenSize();
		int x=screen.width;
		int y=screen.height;
		
		f.setSize(300,300);
		int xcenter=(x-300)/2;
		int ycenter=(y-300)/2;
		f.setLocation(xcenter,ycenter);//��ʾ�ڴ�������
		
		f.setVisible(true);
		
		//------------------------------------------------------------------
		j1.addActionListener((ActionListener) this);//ע���¼�������
		j2.addActionListener((ActionListener) this);
		
		f.addWindowListener(
		new WindowAdapter()
		{
			public void windowClosing(WindowEvent e)
			{
				System.exit(0);
			}
		}
		);
		
	}
	public void confirm()
	{
		try{
			Class.forName("org.gjt.mm.mysql.Driver");
		}
		catch(ClassNotFoundException e){System.out.println("������������ʧ�ܣ�");}
		try{

			Connection con=(Connection) DriverManager.getConnection("jdbc:mysql://172.18.33.178/test","root","123456");
			Statement sql=con.createStatement();
			
			//String uname=t1.getText().trim();  lp
			//System.out.println(uname);
			getUname();
			
			//String Mima=t2.getText().trim();
			//System.out.println(Mima);
			getPswd();
			
			String queryMima="select * from myuser where name='"+uname+"' and password='"+Mima+"'";
			ResultSet rs=sql.executeQuery(queryMima);
			//System.out.print("!!!");
			if(rs.next())
			{
				System.out.print("!!!");
				new Book("");
				f.hide();
				con.close();
				
			}
			else
			{
				JOptionPane.showMessageDialog(null,"���û�������","��ʾ��",JOptionPane.YES_NO_OPTION);
				
			}
			t1.setText("");
			t2.setText("");
		}catch(SQLException g)
		{
			System.out.println("E Code"+g.getErrorCode());
			System.out.println("E M"+g.getMessage());
		}
	}


	public void actionPerformed(ActionEvent e)
	{
		String cmd=e.getActionCommand();
		if(cmd.equals("ȷ��"))
		{
			confirm();
		}
		else if(cmd.equals("ȡ��"))
		{
			f.dispose();
		}
	}
	
/*	public static void main(String []arg)
	{
		Login a=new Login();
	}
	*/
}