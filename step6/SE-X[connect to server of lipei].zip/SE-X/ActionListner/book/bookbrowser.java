package book;
import java.awt.event.*;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.Container;
import java.util.*;

import javax.swing.*;
import java.awt.*;
import javax.swing.*;

public class bookbrowser implements ActionListener
{
	public JFrame f;
	public Container cp;
	public JPanel jpS,jpanelWest;
	public JButton jbt1;
	public JButton jbt2;//��ť��ѯȡ���޸�
	public JButton jbt3;
    public JLabel label,L; //��ǩ  �����ı���
    public JTable table;//�����������ݿ��з���ideas��Ϣ
    public Object columnName[]={"ͼ����","ͼ���","����","����","������","���ʱ��","��ַ"};
    public Object ar[][]=new Object[80][7];
    public String sno;
    public String count="xx";
   
    public bookbrowser()
    {
    	f=new JFrame("ͼ�����");
    	cp=f.getContentPane(); //��ʼ����壬��ť����ǩ���ı���
    	jpS=new JPanel();
    	jpanelWest=new JPanel();
    	jbt1=new JButton("ȷ��");
    	jbt2=new JButton("����");
    	jbt3=new JButton("��");
    	
    	label=new JLabel("<html><font color=#cc00ff size='4'>ͼ�����</front>",SwingConstants.CENTER);
    	label.setForeground(Color.blue);
    	L=new JLabel("������ڹ���ͼ��"+count+"��");
    	
    	table=new JTable(ar,columnName);//ar��ű������ݡ�columnname��ʾ����
    	JScrollPane scrollpane=new JScrollPane(table);
    	
    	jpS.add(jbt1);
    	jpS.add(jbt2);
    	jpS.add(jbt3);
    	
    	JPanel jpanel=new JPanel();
    	jpanel.add(label);
    	
    	JPanel pp4=new JPanel();
    	JPanel jpE=new JPanel();
    	
    	cp.add(jpanel,"North");
    	JPanel jp=new JPanel();
    	JPanel p=new JPanel();
    	p.setLayout(new BorderLayout());
    	
    	p.add(L,"North");
    	p.add(scrollpane);
    	
    	cp.add(pp4,"West");
    	cp.add(p,"Center");
    	cp.add(jpS,"South");
    	cp.add(jpE,"East");
    	
    	Toolkit kit=Toolkit.getDefaultToolkit();
    	Dimension screen=kit.getScreenSize();
    	int x=screen.width;
    	int y=screen.height;
    	f.setSize(400,330);
    	int xcenter=(x-350)/2;
    	int ycenter=(y-350)/2;
    	f.setLocation(xcenter,ycenter);
    	f.setVisible(true);
    	jbt1.addActionListener(this);
    	jbt2.addActionListener(this);
    	jbt3.addActionListener(this);
    	

    }
public void showRecord()
{
	int i=0;
	while(i>=0)
	{
		ar[i][0]="";
		ar[i][1]="";
		ar[i][2]="";
		ar[i][3]="";
		ar[i][4]="";
		ar[i][5]="";
		ar[i][6]="";
		i--;
	}
	i=0;
	//try{
		//Class.forName("sun.jdbc.odbc.jdbcodbcdriver");
		//String url="jdbc:odbc:driver={Microsoft Access Driver (*.mdb)};DBQ=Book.mdb";
	//	Class.forName("com.microsoft.jdbc.sqlserver.SQLServerDriver");//.newInstance(); 
	//}
	//catch(ClassNotFoundException e)
	//{
	//	System.out.println("������������ʧ�ܣ�");
	//}
	try{
		//String url="jdbc:odbc:driver={Microsoft Access Driver (*.mdb)};DBQ=Book.mdb";
		//String url="jdbc:microsoft:sqlserver://localhost:1433;DatabaseName=mydb";  
		//mydbΪ���ݿ�  
		//String user="sa";  
		//String password="";   
		//Connection con=DriverManager.getConnection(url);
		Class.forName("org.gjt.mm.mysql.Driver");
		Connection conn=(Connection) DriverManager.getConnection("jdbc:mysql://172.18.33.178/test","root","123456");
		Statement sql=conn.createStatement();
		String s="select * from mybook ";
		ResultSet rs=sql.executeQuery(s);
		
		while(rs.next())
		{
			String bname=rs.getString(1);
			String bno=rs.getString(2);
			String price=rs.getString(3);
			String writer=rs.getString(4);
			String publish=rs.getString(5);
			String indate=rs.getString(6);
			String dir=rs.getString(7);
			ar[i][0]=bname;
			ar[i][1]=bno;
			ar[i][2]=price;
			ar[i][3]=writer;
			ar[i][4]=publish;
			ar[i][5]=indate;
			ar[i][6]=dir;
			i++;
		}
		count=""+i+"";
		L.setText("������ڹ���ͼ��"+count+"��");
		f.repaint();
		
		conn.close();
	}catch(SQLException g)
	{
		System.out.println("E Code"+g.getErrorCode());
		System.out.println("E M"+g.getMessage());
	}
	catch(Exception ee){
		ee.printStackTrace();
	}
}
public void actionPerformed(ActionEvent e)
{
String cmd=e.getActionCommand();
	if(cmd.equals("ȷ��"))
	{
		f.hide();
	}
	if(cmd.equals("����"))
		f.hide();
	if(cmd.equals("��"))
	{
		/*table.setRowSelectionInterval(1,1);
		table.setColumnSelectionInterval(1,1);
		table.editCellAt(1, 1);
		DefaultCellEditor cell = (DefaultCellEditor)table.getCellEditor(1, 1);
		cell.getComponent().requestFocus(); */
		 int row = table.getSelectedRow();
	        int column = table.getSelectedColumn();

	        DefaultCellEditor obj = (DefaultCellEditor) (table.getColumnModel()
	                .getColumn(column).getCellEditor());
	        
	           

	            System.out.println("row:" + row + " ,column:" + column + " ,value:"
	                    );
	        
		try {
			Runtime.getRuntime().exec("C:/Program Files/Microsoft Office/OFFICE11/WINWORD.exe "+ar[row][6]);
		} catch (IOException e1) {
			// TODO �Զ����� catch ��
			e1.printStackTrace();
		} 
	}
}
}
