package defaultpackage;

import java.awt.event.*;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Toolkit;
import javax.swing.*;
import java.awt.*;
import javax.swing.border.TitledBorder;


@SuppressWarnings("serial")
public
class Book extends JFrame implements ActionListener
{
	JButton QueryScore=new JButton("ͼ���ѯ");
	JButton QueryXuefen=new JButton("ͼ�����");
	JButton jiangfa=new JButton("ͼ��ɾ��");
	JButton xuanke=new JButton("ͼ��Ԥ��");
	JButton gaiMima=new JButton("�޸�����");
	JMenuBar mb=new JMenuBar();//�˵�
	JPanel jp=new JPanel();//���������ģ��
	Container cp=getContentPane();
	String username;
	public Book()
	{
		
	}
	public Book(String username)
	{
		this.username=username;
		mb.add(QueryScore);
		mb.add(QueryXuefen);
		mb.add(jiangfa);
		mb.add(jiangfa);
		mb.add(xuanke);
		mb.add(gaiMima);
		cp.add(mb,"North");
		
		//���ñ߿�
		jp.setBorder(BorderFactory.createTitledBorder(BorderFactory
				.createLineBorder(Color.blue,2),null,TitledBorder.CENTER,
				 TitledBorder.TOP));
		jp.setLayout(new BorderLayout());
		JScrollPane scrollpane=new JScrollPane(jp);
		cp.add(scrollpane);
		setTitle("��ӭ��½");
		
		Toolkit kit=Toolkit.getDefaultToolkit();
		Dimension screen=kit.getScreenSize();
		int x=screen.width;
    	int y=screen.height;
    	setSize(900,900);
    	int xcenter=(x-900)/2;

        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //ע��������
        QueryScore.addActionListener(this);
        QueryXuefen.addActionListener(this);
        jiangfa.addActionListener(this);
        xuanke.addActionListener(this);
        gaiMima.addActionListener(this);
        
	}
	public void actionPerformed(ActionEvent e)
	{
		String cmd=e.getActionCommand();
		if(cmd.equals("ͼ���ѯ"))
		{
			new QueryBook();
		}
		if(cmd.equals("ͼ�����"))
		{
			new BookIn();
		}
/*	    if (cmd.equals("ͼ��ɾ��"))
	    {
	    	new RemoveBook();
	    }*/
	    if(cmd.equals("ͼ��Ԥ��"))
	    {
	    	new bookbrowser().showRecord();
	    }
/*		if(cmd.equals("�޸�����"))
		{
			new UpdateMima(username);
		}*/
	}
	
	
	public static void main() {
		// TODO �Զ����ɷ������

		new Book("");
		System.out.print("!!");
	}
}