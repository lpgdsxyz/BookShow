import java.awt.event.*;
import javax.swing.*;

class NewMenuBar{
	private JMenuBar menuBar;
//	private boolean isLogIn = false, hasChosen = false, hasEdited = false, hasBack = false;
	
	private JMenu File, Edit, Book, Category, Search, Help;
	
	private JMenuItem Open, Save, Refresh, LogIn, LogOut, Exit;
	private JMenuItem Undo, Redo, Cut, Copy, Paste, Delete, SelectAll;
//	private JMenuItem NewBook, EditBook, AddComment, EditComment, DeleteComment;
//	private JMenuItem NewCategory, EditCategory, DeleteCategory;
	private JMenuItem SearchLocal, SearchOL;
	private JMenuItem AboutUs, HelpContents;
	
	public NewMenuBar(){
		menuBar = new JMenuBar();
	}
	
	public JMenuBar GetMenuBar(){
		return menuBar;
	}
	
	public void BuildMenuBar(){
		menuBar.add(getFileMenu());
		menuBar.add(getEditMenu());
		menuBar.add(getBookMenu());
		menuBar.add(getCategoryMenu());
		menuBar.add(getSearchMenu());
		menuBar.add(getHelpMenu());
	}

	private JMenu getFileMenu(){
		if (File == null){
			File = new JMenu("�ļ�(F)");
			File.setMnemonic(KeyEvent.VK_F);
	        File.removeAll();
	        File.add(getOpenItem());
	        File.add(getSaveItem());
	        File.add(getRefreshItem());
	        File.addSeparator();
	        File.add(getLogInItem());
	        File.add(getLogOutItem());
	        File.addSeparator();
	        File.add(getExitItem());
		}
		File.setEnabled(true);
		return File;
	}
	
	private JMenu getEditMenu(){
		if(Edit == null){
			Edit = new JMenu("�༭(E)");
			Edit.setMnemonic(KeyEvent.VK_E);
	        Edit.removeAll();
	        Edit.add(getUndoItem());
	        Edit.add(getRedoItem());
	        Edit.addSeparator();
	        Edit.add(getCutItem());
	        Edit.add(getCopyItem());
	        Edit.add(getPasteItem());
	        Edit.addSeparator();
	        Edit.add(getDeleteItem());
	        Edit.add(getSelectAllItem());
		}
		Edit.setEnabled(true);
		return Edit;
	}
	
	private JMenu getBookMenu(){
		if(Book == null){
			Book = new JMenu("�ĵ�����(B)");
			Book.setMnemonic(KeyEvent.VK_B);
	        //Book.removeAll();
			//Book.add(getNewBookItem());
			//Book.add(getEditBookItem());
	        //Book.addSeparator();
			//Book.add(getAddCommentItem());
			//Book.add(getEditCommentItem());
			//Book.add(getDeleteCommentItem());
		}
		Book.setEnabled(true);
		return Book;
	}
	
	private JMenu getCategoryMenu(){
		if(Category == null){
			Category = new JMenu("Ŀ¼����(C)");
			Category.setMnemonic(KeyEvent.VK_C);
	        //Category.removeAll();
			//Category.add(getNewCategoryItem());
			//Category.add(getEditCategoryItem());
			//Category.add(getDeleteCategoryItem());
	        //Category.addSeparator();
		}
		Category.setEnabled(true);
		return Category;
	}
	
	private JMenu getSearchMenu(){
		if(Search == null){
			Search = new JMenu("����(S)");
			Search.setMnemonic(KeyEvent.VK_S);
	        Search.removeAll();
	        Search.add(getSearchLocalItem());
	        Search.add(getSearchOLItem());
		}
		Search.setEnabled(true);
		return Search;
	}
	
	private JMenu getHelpMenu(){
		if(Help == null){
			Help = new JMenu("Ŀ¼����(C)");
			Help.setMnemonic(KeyEvent.VK_H);
			Help.removeAll();
	        Help.add(getHelpContentsItem());
	        Help.addSeparator();
	        Help.add(getAboutUsItem());
		}
		Help.setEnabled(true);
		return Help;
	}
	
	/*
	 * ��ʼ��File�˵���ķ���
	 */
	
	private JMenuItem getOpenItem(){
		Open = new JMenuItem("��");
		Open.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_O, InputEvent.ALT_MASK));
		Open.addActionListener(new ActionListener(){
	        public void actionPerformed(ActionEvent evt){
//	       		OpenFile();
	        }
		});
		Open.setEnabled(true);
		return Open;
	}
	
	private JMenuItem getSaveItem(){
		if(Save == null){
			Save = new JMenuItem("����");
			Save.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S, InputEvent.ALT_MASK));
			Save.addActionListener(new ActionListener(){
	        	public void actionPerformed(ActionEvent evt){
//	        		SaveChange();
	        	}
			});
		}
		Save.setEnabled(true);
		return Save;
	}
	
	private JMenuItem getRefreshItem(){
		if(Refresh == null){
			Refresh = new JMenuItem("ˢ��");
			Refresh.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F5, InputEvent.ALT_MASK));
			Refresh.addActionListener(new ActionListener(){
	        	public void actionPerformed(ActionEvent evt){
//	        		Refresh();
	        	}
			});
		}
		Refresh.setEnabled(true);
		return Refresh;
	}
	
	private JMenuItem getLogInItem(){
		if(LogIn == null){
			LogIn = new JMenuItem("��½");
			LogIn.addActionListener(new ActionListener(){
	        	public void actionPerformed(ActionEvent evt){
//	        		LogIn();
	        	}
			});
		}
		LogIn.setEnabled(true);
		return LogIn;
	}
	
	private JMenuItem getLogOutItem(){
		if(LogOut == null){
			LogOut = new JMenuItem("�˳���¼");
			LogOut.addActionListener(new ActionListener(){
	        	public void actionPerformed(ActionEvent evt){
	        		//LogOut();
	        	}
			});
		}
		LogOut.setEnabled(true);
		return LogOut;
	}
	
	private JMenuItem getExitItem(){
		if(Exit == null){
			Exit = new JMenuItem("��������");
			Exit.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_X, InputEvent.ALT_MASK));
//			Exit.setMnemonic(KeyEvent.VK_X);
			Exit.addActionListener(new ActionListener(){
	        	public void actionPerformed(ActionEvent evt){
	        		System.exit(0);
	        	}
			});
		}
		Exit.setEnabled(true);
		return Exit;
	}	
	
	/*
	 * ��ʼ��Edit�˵���ķ���
	 */
	
	private JMenuItem getUndoItem(){
		if(Undo == null){
			Undo = new JMenuItem("����");
			Undo.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_Z, InputEvent.CTRL_MASK));
			Undo.addActionListener(new ActionListener(){
	        	public void actionPerformed(ActionEvent evt){
	        		//Undo();
	        	}
			});
		}
		Undo.setEnabled(true);
		return Undo;
	}
	
	private JMenuItem getRedoItem(){
		if(Redo == null){
			Redo = new JMenuItem();
			Redo.setText("�ָ�");
			Redo.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_Y, InputEvent.CTRL_MASK));
			Redo.addActionListener(new ActionListener(){
	        	public void actionPerformed(ActionEvent evt){
	        		//Redo();
	        	}
			});
		}
		Redo.setEnabled(true);
		return Redo;
	}
	
	private JMenuItem getCutItem(){
		if(Cut == null){
			Cut = new JMenuItem();
			Cut.setText("����");
			Cut.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_X, InputEvent.CTRL_MASK));
			Cut.addActionListener(new ActionListener(){
	        	public void actionPerformed(ActionEvent evt){
	        		//Cut();
	        	}
			});
		}
		Cut.setEnabled(true);
		return Cut;
	}
	
	private JMenuItem getCopyItem(){
		if(Copy == null){
			Copy = new JMenuItem();
			Copy.setText("����");
			Copy.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_C, InputEvent.CTRL_MASK));
			Copy.addActionListener(new ActionListener(){
	        	public void actionPerformed(ActionEvent evt){
	        		//Copy();
	        	}
			});
		}
		Copy.setEnabled(true);
		return Copy;
	}
	
	private JMenuItem getPasteItem(){
		if(Paste == null){
			Paste = new JMenuItem();
			Paste.setText("ճ��");
			Paste.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_V, InputEvent.CTRL_MASK));
			Paste.addActionListener(new ActionListener(){
	        	public void actionPerformed(ActionEvent evt){
	        		//Paste();
	        	}
			});
		}
		Paste.setEnabled(true);
		return Paste;
	}
	
	private JMenuItem getDeleteItem(){
		if(Delete == null){
			Delete = new JMenuItem();
			Delete.setText("ɾ��");
			Delete.addActionListener(new ActionListener(){
	        	public void actionPerformed(ActionEvent evt){
	        		//DeleteBook();
	        	}
			});
		}
		Delete.setEnabled(true);
		return Delete;
	}
	
	private JMenuItem getSelectAllItem(){
		if(SelectAll == null){
			SelectAll = new JMenuItem("ȫѡ");
			SelectAll.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_A, InputEvent.CTRL_MASK));
			SelectAll.addActionListener(new ActionListener(){
	        	public void actionPerformed(ActionEvent evt){
	        		//SelsctAll();
	        	}
			});
		}
		SelectAll.setEnabled(true);
		return SelectAll;
	}
	
	/*
	 * ��ʼ��Book�˵���ķ���
	 * NewBook, EditBook, AddComment, EditComment
	 */

/*	private JMenuItem getNewBookItem(){
		if(NewBook == null){
			NewBook = new JMenuItem("�����ĵ�");
			NewBook.addActionListener(new ActionListener(){
	        	public void actionPerformed(ActionEvent evt){
	        		//AddBook();
	        	}
			});
		}
		NwBook.setEnabled(true);
		return NewBook;
	}
	
	private JMenuItem getEditBookItem(){
		if(EditBook == null){
			EditBook = new JMenuItem("�޸��ĵ���Ϣ");
			EditBook.addActionListener(new ActionListener(){
	        	public void actionPerformed(ActionEvent evt){
	        		//ChangeBookImformation();
	        	}
			});
		}
		EditBook.setEnabled(true);
		return EditBook;
	}
	
	private JMenuItem getAddCommentItem(){
		if(AddComment == null){
			AddComment = new JMenuItem("��������");
			AddComment.addActionListener(new ActionListener(){
	        	public void actionPerformed(ActionEvent evt){
	        		//AddComment();
	        	}
			});
		}
		AddComment.setEnabled(true);
		return AddComment;
	}
	
	private JMenuItem getEditCommentItem(){
		if(EditComment == null){
			EditComment = new JMenuItem("�޸�����");
			EditComment.addActionListener(new ActionListener(){
	        	public void actionPerformed(ActionEvent evt){
	        		//ChangeComment();
	        	}
			});
		}
		EditComment.setEnabled(true);
		return EditComment;
	}
	
	private JMenuItem getDeleteCommentItem(){
		if(DeleteComment == null){
			DeleteComment = new JMenuItem("�޸�����");
			DeleteComment.addActionListener(new ActionListener(){
	        	public void actionPerformed(ActionEvent evt){
	        		//DeleteComment();
	        	}
			});
		}
		DeleteComment.setEnabled(true);
		return DeleteComment;
	}
	*/
	
	/*
	 * ��ʼ��Category�˵���ķ���
	 * NewCategory, EditCategory, DeleteCategory
	 */
	/*
	private JMenuItem getNewCategoryItem(){
		if(NewCategory == null){
			NewCategory = new JMenuItem("����Ŀ¼");
			NewCategory.addActionListener(new ActionListener(){
	        	public void actionPerformed(ActionEvent evt){
	        		//AddCategory();
	        	}
			});
		}
		NewCategory.setEnabled(true);
		return NewCategory;
	}
	
	private JMenuItem getEditCategoryItem(){
		if(EditCategory == null){
			EditCategory = new JMenuItem("�޸�Ŀ¼");
			EditCategory.addActionListener(new ActionListener(){
	        	public void actionPerformed(ActionEvent evt){
	        		//ChangeCategory();
	        	}
			});
		}
		EditCategory.setEnabled(true);
		return EditCategory;
	}
	
	private JMenuItem getDeleteCategoryItem(){
		if(DeleteCategory == null){
			DeleteCategory = new JMenuItem("ɾ��Ŀ¼");
			DeleteCategory.addActionListener(new ActionListener(){
	        	public void actionPerformed(ActionEvent evt){
	        		//DeleteCategory
	        	}
			});
		}
		DeleteCategory.setEnabled(true);
		return DeleteCategory;
	}
	*/
	
	/*
	 * ��ʼ��Search�˵���ķ���
	 */
	
	private JMenuItem getSearchLocalItem(){
		if(SearchLocal == null){
			SearchLocal = new JMenuItem("���������ĵ�");
			SearchLocal.addActionListener(new ActionListener(){
	        	public void actionPerformed(ActionEvent evt){
	        		//SearchLocal
	        	}
			});
		}
		SearchLocal.setEnabled(true);
		return SearchLocal;
	}
	
	private JMenuItem getSearchOLItem(){
		if(SearchOL == null){
			SearchOL = new JMenuItem("���������ĵ�");
			SearchOL.addActionListener(new ActionListener(){
	        	public void actionPerformed(ActionEvent evt){
	        		//SearchOnLine
	        	}
			});
		}
		SearchOL.setEnabled(true);
		return SearchOL;
	}
	
	private JMenuItem getAboutUsItem(){
		if(AboutUs == null){
			AboutUs = new JMenuItem("��������");
			AboutUs.addActionListener(new ActionListener(){
	        	public void actionPerformed(ActionEvent evt){
	        		//AboutUs();
	        	}
			});
		}
		AboutUs.setEnabled(true);
		return AboutUs;
	}
	
	private JMenuItem getHelpContentsItem(){
		if(HelpContents == null){
			HelpContents = new JMenuItem("����");
			HelpContents.addActionListener(new ActionListener(){
	        	public void actionPerformed(ActionEvent evt){
	        		//HelpContents();
	        	}
			});
		}
		HelpContents.setEnabled(true);
		return HelpContents;
	}

	/*
	public boolean GetIsLogIn(){
		return isLogIn;
	}
	
	public boolean GetHasChosen(){
		return hasChosen;
	}
	
	public boolean GetHasEdited(){
		return hasEdited;
	}
	
	public boolean GetHasBack(){
		return hasBack;
	}
	
	public void SetBoolean(boolean bool){
		if(bool){
			bool = false;
		}
		else{
			bool = true;
		}
	}
	
	public void SetMenuBarByBool(boolean bool){
		if( bool == false ){
			DoIfBoolFalse();
		}
		else{
			DoIfBoolTrue();
		}
	}
	
 	private void DoIfBoolFalse(){
		//��������
	}
	
	private void DoIfBoolTrue(){
		//��������
	}
	
	private void SetMenuUnabled(JMenu menu){
		if( menu.isEnabled() == true ){
			menu.setEnabled(false);
		}
	}
	
	private void SetMenuEnabled(JMenu menu){
		if( menu.isEnabled() == false ){
			menu.setEnabled(true);
		}
	}
*/
	
}