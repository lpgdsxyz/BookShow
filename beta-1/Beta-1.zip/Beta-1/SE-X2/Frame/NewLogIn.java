import java.awt.*;
import java.awt.event.*;

import defaultpackage.*;

import javax.swing.*;

@SuppressWarnings("serial")
class NewLogIn extends JFrame implements ActionListener{
	private JLabel nameLabel, passwordLabel, welcomeLabel;
	private JTextField txtName, txtPassword;
	private JButton btnLogIn, btnReset, btnExit;
	private String userName="rl";
	private String userPassword="12345";
	private defaultpackage.Book mainFrame;
//	private NewFrame frameMain;
	private boolean isLogIn;
	
	public NewLogIn(){
		super(); 
	}
 
	public void setMyID(String name,String password){
		userName = name;
		userPassword = password;
	}
 
	public void initFrame(){
		nameLabel = new JLabel("������", JLabel.CENTER);
		nameLabel.setBounds(20, 40, 70, 30);
		
		txtName = new JTextField("");
		txtName.setBounds(100, 40, 100, 30);
		
		getContentPane().add(nameLabel);
		getContentPane().add(txtName);
		
		passwordLabel = new JLabel("���룺", JLabel.CENTER);
		passwordLabel.setBounds(20, 80, 70, 30);
		
		txtPassword = new JTextField("");
		txtPassword.setBounds(100, 80, 100, 30);
		
		getContentPane().add(passwordLabel);
		getContentPane().add(txtPassword);
		
		btnLogIn = new JButton("��¼");
		btnLogIn.setBounds(5, 120, 70, 30);
		btnLogIn.addActionListener(new java.awt.event.ActionListener(){
			public void actionPerformed(java.awt.event.ActionEvent evt){
				LogIn();	
			}
		});
		getContentPane().add(btnLogIn);
		
		btnReset = new JButton("����");
		btnReset.setBounds(80, 120, 70, 30);
		btnReset.addActionListener(new java.awt.event.ActionListener(){
			public void actionPerformed(java.awt.event.ActionEvent evt){
				Reset();	
			}
		});
		getContentPane().add(btnReset);
		
		btnExit = new JButton("�˳�");
		btnExit.setBounds(155, 120, 70, 30);
		btnExit.addActionListener(new java.awt.event.ActionListener(){
			public void actionPerformed(java.awt.event.ActionEvent evt){
				Exit();	
			}
		});
		getContentPane().add(btnExit);
		
		getContentPane().setBackground(new Color(225, 225, 225)); 
		getContentPane().setLayout(null);
		this.setTitle("��¼����");
		this.setDefaultCloseOperation(3);
		this.setSize(240,200);
		this.setLocation(400,200);
		this.setResizable(false);
		this.setVisible(true);
	}
	
	
	public void LogIn(){
		if( txtName.getText().equalsIgnoreCase(userName) && txtPassword.getText().equalsIgnoreCase(userPassword) ){
			SetIsLogIn(true);
			welcomeLabel = new JLabel("��ӭʹ��");
			welcomeLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
			Exit();
			JOptionPane.showMessageDialog(null, welcomeLabel, "��ӭʹ��", 2);
			mainFrame = new Book();
			mainFrame.main();
		}
		else{
			JOptionPane.showMessageDialog(null, "��������ȷ���û��������룡");
			Reset();
		}
	}
	
	public void Reset(){
		txtName.setText("");
		txtPassword.setText("");
	}
	
	public void Exit(){
		this.setVisible(false);
	}
	
	public void SetIsLogIn(boolean bool){
		isLogIn = bool;
	}
	
	public boolean GetIsLogIn(){
		return isLogIn;
	}
	
	public static void main(String args[]){
		try {
            UIManager.setLookAndFeel(
                    "com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
        } catch (ClassNotFoundException ex) {
            ex.printStackTrace();
        } catch (InstantiationException ex) {
            ex.printStackTrace();
        } catch (IllegalAccessException ex) {
            ex.printStackTrace();
        } catch (UnsupportedLookAndFeelException ex) {
            ex.printStackTrace();
        }
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
				NewLogIn Window = new NewLogIn();
				Window.initFrame();
            }
        });
	}
/*		
	public static void main(String args[]){
		try {
            UIManager.setLookAndFeel(
                    "com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
        } catch (ClassNotFoundException ex) {
            ex.printStackTrace();
        } catch (InstantiationException ex) {
            ex.printStackTrace();
        } catch (IllegalAccessException ex) {
            ex.printStackTrace();
        } catch (UnsupportedLookAndFeelException ex) {
            ex.printStackTrace();
        }
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new NewFrame().setVisible(true);
            }
        });
	}
*/
	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
	}
}
	
