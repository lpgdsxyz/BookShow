import java.awt.*;
import java.sql.DriverManager;

import javax.swing.*;
import java.util.*;
import java.sql.*;

@SuppressWarnings("serial")
class NewFrame extends JFrame{

	private JLabel searchLabel1, searchLabel2, choiceType, choiceWeb, scrollCategery, scrollBook;
	private JTextField txtSearchLocal,txtSearchOnline;
	private JButton btnSearchLocal,btnSearchOnline;
	private JComboBox searchL, searchO;
	private JScrollPane scrollPane1, scrollPane2;
	private NewMenuBar menuBar;
	
	public NewFrame() {
        initFrame();
    }
	
	public NewFrame(String str){
		super(str);
	}
	
	private void initFrame(){
		
		menuBar = new NewMenuBar();
		menuBar.BuildMenuBar();

		searchLabel1 = new JLabel("��������", JLabel.CENTER);
        searchLabel1.setBounds(30, 0, 750, 20);
        getContentPane().add(searchLabel1);
        
		txtSearchLocal = new JTextField("");
		txtSearchLocal.setBounds(50, 30, 400, 20);
		getContentPane().add(txtSearchLocal);
		
		choiceType = new JLabel("�ؼ������ͣ�", JLabel.RIGHT);
		choiceType.setBounds(470, 30, 80, 20);
		getContentPane().add(choiceType);
		
		String str1[] = {"��ѡ��", "����", "����", "Ŀ¼"};
		searchL = new JComboBox(str1);
		searchL.setBounds(570, 30, 80, 20);
		getContentPane().add(searchL);
		
		btnSearchLocal = new JButton("����");
		btnSearchLocal.setBounds(670, 30, 60, 20);
		btnSearchLocal.addActionListener(new java.awt.event.ActionListener(){
			public void actionPerformed(java.awt.event.ActionEvent evt){
			}
		});
		getContentPane().add(btnSearchLocal);
		
		JPanel panelInside1 = new JPanel();
		panelInside1.setLayout(new java.awt.GridLayout());
		
		scrollCategery = new JLabel("Ŀ¼", JLabel.CENTER);
		panelInside1.add(scrollCategery);
		
		scrollPane1 = new JScrollPane(panelInside1);
		scrollPane1.setBounds(30, 60, 100, 400);
		panelInside1.setPreferredSize(new Dimension(scrollPane1.getWidth()-50, scrollPane1.getHeight()*2));
		getContentPane().add(scrollPane1);
		
		JPanel panelInside2 = new JPanel();
		panelInside2.setLayout(new java.awt.GridLayout());
		
		scrollBook = new JLabel("�ĵ�", JLabel.CENTER);
		panelInside2.add(scrollBook);
		
		scrollPane2 = new JScrollPane(panelInside2);
		scrollPane2.setBounds(150, 60, 620, 400);
		panelInside2.setPreferredSize(new Dimension(scrollPane2.getWidth()-50, scrollPane2.getHeight()*2));
		getContentPane().add(scrollPane2);
		
		searchLabel2 = new JLabel("��������", JLabel.CENTER);
		searchLabel2.setBounds(30, 470, 750, 20);
		getContentPane().add(searchLabel2);
        
		txtSearchOnline = new JTextField("");
		txtSearchOnline.setBounds(50, 500, 400, 20);
		getContentPane().add(txtSearchOnline);
		
		choiceWeb = new JLabel("��վ��", JLabel.RIGHT);
		choiceWeb.setBounds(470, 500, 60, 20);
		getContentPane().add(choiceWeb);

		String str2[] = {"��ѡ��", "�ٶ�", "google", "�Ա�", "׿Խ", "����"};
		searchO = new JComboBox(str2);
		searchO.setBounds(550, 500, 100, 20);
		getContentPane().add(searchO);
		
		btnSearchOnline = new JButton("����");
		btnSearchOnline.setBounds(670, 500, 60, 20);
		btnSearchOnline.addActionListener(new java.awt.event.ActionListener(){
			public void actionPerformed(java.awt.event.ActionEvent evt){
				//���ð�ť���ܺ���	
			}
		});
		getContentPane().add(btnSearchOnline);
		
		getContentPane().setBackground(new Color(225, 225, 225)); 
		getContentPane().setLayout(null);
		
		this.setJMenuBar(menuBar.GetMenuBar());
		this.setTitle("�����������");
		this.setDefaultCloseOperation(3);
		this.setSize(800,600);
		this.setLocation(150,100);
		this.setResizable(false);
		this.setVisible(true);
	}

}
		
			
	

