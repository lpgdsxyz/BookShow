package View;
import javax.swing.*;

import Controller.getBookTableInfo;


import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Runner {
	JFrame mf;
	JTable mt;
	JButton mb;
	Container ct;
	
	
	public Runner(){
		mf=new JFrame();
		mf.setSize(400,400);
		
		mb=new JButton("Book");
		
		ct=mf.getContentPane();
		ct.setLayout(new FlowLayout());
		ct.add(mb);
		
		mb.addActionListener(new BookButtonListener(ct,mt));
				
		mf.setVisible(true);
	}
	
	private class BookButtonListener implements java.awt.event.ActionListener{
		private Container ac_ct;
		private JTable ac_mt;	
		
		BookButtonListener(Container _ct,JTable _mt){
			ac_ct=_ct;
			ac_mt=_mt;			
		}
		
		public void actionPerformed(ActionEvent e1) {
			Object info[][]=null;
			String columnNames[]=null;	
			
			try{
				getBookTableInfo get1=new getBookTableInfo();
				//System.out.println("get ok");
				//��������س���
				info=get1.ctrl_info.clone();
				columnNames=get1.ctrl_columnNames.clone();
				//System.out.println(columnNames.length);
				
				ac_mt=new JTable(info,columnNames);
				//System.out.println("table ok");
				//int i=ac_mt.getX();
				//System.out.println(i);
				ac_ct.add(ac_mt);
				//System.out.println("set ok");
				
			}
			catch( NullPointerException e){
				System.out.println("catch me");
			}
			mf.setVisible(true);
		}
	}
	
	public static void main(String[] args)
	{
			new Runner();
	}
}
