package Controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;


public class getBookTableInfo {
	public Object ctrl_info[][];
	public String ctrl_columnNames[];
	
	public getBookTableInfo(){
		//_columnNames=ctrl_columnNames;
		//ctrl_info=_info;
		get_Info_and_columnNames();
		
		/*ctrl_columnNames=new String[3];
		ctrl_columnNames[0]="c0";
		ctrl_columnNames[1]="c1";
		ctrl_columnNames[2]="c2";
		*/
		//_columnNames=ctrl_columnNames.clone();
		//_info=ctrl_info.clone();
		
		//System.out.println("_columnNames.length is "+_columnNames.length);
	}
	/*
	public static void main(String[] arg){
		Object info[][]=null;
		String names[]=null;
		try{
			getBookTableInfo get1=new getBookTableInfo();
			info=get1.ctrl_info.clone();
			names=get1.ctrl_columnNames.clone();
			System.out.println("_columnNames.length is "+names.length);
		}
		catch(Exception e){
			System.out.println("wrong ");
		}
		
	}
	*/
	void get_Info_and_columnNames(){

		// TODO Auto-generated method stub
		//System.out.println("Action 2");
		ResultSetMetaData rsmd=null;
		
		//��ʼ�������ݿ�	
		try{
			//1.ע������
			Class.forName("com.mysql.jdbc.Driver");
			}
		catch(ClassNotFoundException e){
			e.printStackTrace();
			}//MySql������
		    //�������ݿ��������ʵ��
		Connection con=null;//���ݿ����Ӷ���

		Statement stm=null;//���ݿ����ʽ

		ResultSet rs=null;//�����

		try{//2.�������ݿ������
			//����һ:���ӵ�MySql���ݿ��JDBC URL;������:�û���;������:����
			con=DriverManager.getConnection("jdbc:mysql://172.18.32.132:3306/test","root","123456");
	       //3.��������ʽ
			stm=con.createStatement();
	       //4.ִ�в�ѯ��¼��SQL���,��ý����
			String searchAll="select * from book";
		    String delete="delete from book where BID=1";
		    String insert="insert into book(BookName,Description) value('The Catcher in the Rye','my favorite')";
		    String getRowNum="select count(*) from book";
		       
		    //stm.executeUpdate(insert);
		    //stm.executeUpdate(delete);
		      
		    rs=stm.executeQuery(getRowNum);
		    rs.next(); 
		    int rowNum=rs.getInt(1);
		       
		    rs=stm.executeQuery(searchAll);
		    rsmd=rs.getMetaData();
		      
		       
		    ctrl_columnNames=new String[rsmd.getColumnCount()];
		    for(int i=0;i<rsmd.getColumnCount();i++)
		    {
		    	ctrl_columnNames[i]=rsmd.getColumnName(i+1);
		    }
		       
		    ctrl_info=new Object[rowNum][];
		       
		    for(int i=0;i<rowNum;i++)
		    {
		    	ctrl_info[i]=new Object[rsmd.getColumnCount()];
		    	while(rs.next())
		    	{
		    		for(int j=0;j<rsmd.getColumnCount();j++)
		    			ctrl_info[i][j]=rs.getObject(j+1);	
		    	}
		    }
		    
		    //���ʽ��� info column Name������Ϣ
		   // this.mt=new JTable(info,columnNames);
		   // this.ct.add(this.mt);
		   // mf.setVisible(true);
		    //this.ct.repaint();
		       
				/*//5.�����������ݿ���ļ�¼
		       while(rs.next()){

		           System.out.print(" ����="+rs.getString("BookName")+"\t");

		           System.out.print(" ����="+rs.getString("Description")+"\t");
		           System.out.print('\n');
		       }*/
		}
		catch(SQLException e){
			e.printStackTrace();
		}
		finally{
		       //�ر����ݿ����ӣ��ͷ���Դ
			try{
				rs.close();
			}
			catch(SQLException e){
				
			}
			
			try{
				stm.close();
			}
			catch(SQLException e){
				
			}
			
			try{
				con.close();
			}
			catch(SQLException e){
				
			}	
		}		
	}

}
